// Load environment variables FIRST before any other imports
import { loadEnvironment, validateEnvironment } from './config/env.js';

// Load and validate environment
loadEnvironment();
validateEnvironment();

import express from 'express';
import {
  globalRateLimit,
  securityHeaders,
  corsConfig,
  jsonSizeLimit,
  denyMultipart,
  errorLogger
} from './middleware/security';
import { sanitizeQuery } from './middleware/validation';
import healthRoutes from './routes/health';
import pingRoutes from './routes/ping.js';
// Temporarily disabled routes with missing dependencies
// import vibeRoutes from './routes/vibe.js';
// import llmRoutes from './routes/llm.js';
// import weatherRoutes from './routes/weather.js';
// import nearbySearchRoutes from './routes/nearbySearch.js';
// import personalizationRoutes from './routes/personalization.js';
// import vibeProfileRoutes from './routes/vibeProfile.js';
// import activitiesSearchRoutes from './routes/activitiesSearch.js';
// import autonomousSearchRoutes from './routes/autonomousSearch.js';
import mcpVibeRoutes from './routes/mcpVibe.js';
import chatRoutes from './routes/chat.js';
import userRoutes from './routes/user.js';
import trainingRoutes from './routes/training.js';
import challengeRoutes from './routes/challenges.js';
import vibeProfileRoutes from './routes/vibeProfiles.js';
import activityFeedbackRoutes from './routes/activityFeedback.js';
import activityCompletionRoutes from './routes/activityCompletion.js';
import communityRoutes from './routes/community.js';
import adminRoutes from './routes/admin.js';
import friendsRoutes from './routes/friends.js';
import uploadRoutes from './routes/upload.js';

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// Security middleware (must be applied in correct order)
app.use(securityHeaders); // Helmet security headers
app.use(corsConfig); // CORS configuration
app.use(globalRateLimit); // Global rate limiting: 300/15min
app.use(jsonSizeLimit); // Limit JSON payload to 100KB
app.use(denyMultipart); // Deny multipart uploads

// Body parsing middleware
app.use(express.json({ limit: '100kb' })); // JSON parsing with size limit
app.use(express.urlencoded({ extended: true, limit: '100kb' }));

// Query sanitization
app.use(sanitizeQuery);

// API Routes
app.use('/api/health', healthRoutes);
app.use('/api/ping', pingRoutes);
// Temporarily disabled routes with missing dependencies
// app.use('/api/vibe', vibeRoutes);
// app.use('/api/llm', llmRoutes);
// app.use('/api/weather', weatherRoutes);
// app.use('/api/nearby', nearbySearchRoutes);
// app.use('/api/personalization', personalizationRoutes);
// app.use('/api/vibe-profile', vibeProfileRoutes);
// app.use('/api/activities', activitiesSearchRoutes);
// app.use('/api/autonomous', autonomousSearchRoutes);
app.use('/api/mcp-vibe', mcpVibeRoutes); // Tag-first PostgreSQL MCP architecture
app.use('/api/chat', chatRoutes); // New conversational chat interface ✨
app.use('/api/user', userRoutes); // User preferences and saved activities ✨
app.use('/api/training', trainingRoutes); // Training feedback collection ✨
app.use('/api/challenges', challengeRoutes); // Challenge Me feature ✨
app.use('/api/vibe-profiles', vibeProfileRoutes); // Custom Vibe Profiles ✨
app.use('/api/activities', activityFeedbackRoutes); // Activity feedback for ML ✨
app.use('/api/activity-completion', activityCompletionRoutes); // Activity completion tracking ✨
app.use('/api/community', communityRoutes); // Community features (feed, reviews, leaderboard) ✨
app.use('/api/admin', adminRoutes); // Admin moderation tools 🛡️
app.use('/api/friends', friendsRoutes); // Friends system (add, search, block, report) 👥
app.use('/api/upload', uploadRoutes); // S3 upload presigned URLs 📤

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    name: 'Vibe API',
    version: '1.0.0',
    description: 'AI-powered activity recommendation API for Romania',
    endpoints: {
      health: '/api/health',
      metrics: '/api/metrics',
      vibeMatch: 'POST /api/vibe/match',
      quickVibeMatch: 'POST /api/vibe/quick-match',
      vibePresets: 'GET /api/vibe/presets',
      vibeOptions: 'GET /api/vibe/options',
      vibeStatus: 'GET /api/vibe/status',
      llmStatus: 'GET /api/llm/status',
      llmParseVibe: 'POST /api/llm/parse-vibe',
      llmCurate: 'POST /api/llm/curate',
      weatherVibeSearch: 'POST /api/weather/vibe-search',
      weatherQuickSearch: 'POST /api/weather/quick-search',
      llmTestFixtures: 'GET /api/llm/test-fixtures',
      pingAll: '/api/ping/all',
      quotaStatus: '/api/ping/quota'
    }
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'not_found',
    message: 'Endpoint not found'
  });
});

// Global error handler
app.use(errorLogger);
app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  // Don't log the full error in production to avoid leaking sensitive info
  const isDev = process.env.NODE_ENV === 'development';
  
  if (isDev) {
    console.error('Unhandled error:', err);
  }

  // Send structured error response
  res.status(500).json({
    error: 'internal_server_error',
    message: isDev ? err.message : 'Something went wrong',
    timestamp: new Date().toISOString()
  });
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🌊 Vibe API server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
  console.log(`Network access: http://10.103.30.198:${PORT}/api/health`);
  
  // Warn if optional env vars are missing (legacy TripAdvisor removed)
  // RAPIDAPI_KEY no longer required - using Google Places API exclusively
  
  // CORS configuration info
  if (process.env.CORS_ORIGINS) {
    console.log('🌐 CORS origins configured:', process.env.CORS_ORIGINS.split(',').map(o => o.trim()).join(', '));
  } else {
    console.log('🌐 CORS using development defaults: localhost, Expo, network access');
  }
});

export default app;
